(function () {
    'use strict';

    window.ACMESTORE = {
      global: {},
      admin: {},
      homeslider: {},
      product: {},
      products: {},
    };
})();
