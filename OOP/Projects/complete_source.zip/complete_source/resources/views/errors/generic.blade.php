
<div style="padding: 15px; width: 80%; margin: 0 auto; border: 1px solid darkgray; border-radius: 5px;">
    <h1>A system error occurred, please try again later.</h1>
</div>