
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<div style="width: 600px; padding: 15px; margin: 0 auto; background-color: #0a0a0a; color: #ffffff;">
    <img src="https://dbqq2ditazz67.cloudfront.net/logos/sm-white-yellow.png" width="150" height="187" />
     <?php echo "Error: {$data}" ?>
    <p>
        Regards <br /> <br />
        <strong>Devscreencast Team</strong>
    </p>
</div>
</body>
</html>
